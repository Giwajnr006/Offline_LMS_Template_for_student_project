<?php
require('../dbconn.php');

// Safe session start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Access control
if (!isset($_SESSION['RollNo'])) {
    echo "<script>alert('Access Denied!'); window.location='../index.php';</script>";
    exit();
}

if (isset($_POST['upload'])) {
    $title = trim($_POST['title']);
    $file = $_FILES['pdf_file'];

    $target_dir = "../uploads/";
    $filename = basename($file["name"]);
    $target_file = $target_dir . $filename;

    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    if ($fileType !== "pdf") {
        echo "<script>alert('Only PDF files are allowed.');</script>";
    } elseif (move_uploaded_file($file["tmp_name"], $target_file)) {
        $stmt = $conn->prepare("INSERT INTO LMS.documents (title, filename) VALUES (?, ?)");
        $stmt->bind_param("ss", $title, $filename);

        if ($stmt->execute()) {
            echo "<script>alert('PDF uploaded successfully');</script>";
        } else {
            echo "<script>alert('Database error');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('File upload failed');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload PDF</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f1f5f9;
            margin: 0;
            padding: 40px;
        }

        .container {
            max-width: 700px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: 600;
            color: #444;
        }

        input[type="text"],
        input[type="file"],
        select,
        textarea {
            width: 100%;
            padding: 10px 12px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 15px;
        }

        textarea {
            resize: vertical;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 25px;
            background-color: #2c7be5;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #236ac6;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Upload a PDF Document</h2>

    <form method="post" enctype="multipart/form-data">
        <label for="title">PDF Title:</label>
        <input type="text" name="title" id="title" required>

        <label for="author">Author:</label>
        <input type="text" id="author" placeholder="Optional - not saved">

        <label for="year">Year:</label>
        <input type="text" id="year" placeholder="Optional - not saved">

        <label for="department">Department:</label>
        <input type="text" id="department" placeholder="Optional - not saved">

        <label for="category">Category:</label>
        <select id="category">
            <option value="">Select Category</option>
            <option value="Thesis">Thesis</option>
            <option value="Project">Project</option>
            <option value="Lecture Note">Lecture Note</option>
            <option value="Manual">Manual</option>
            <option value="Others">Others</option>
        </select>

        <label for="description">Description:</label>
        <textarea id="description" rows="4" placeholder="Optional summary or abstract..."></textarea>

        <label for="pdf_file">Select PDF File:</label>
        <input type="file" name="pdf_file" id="pdf_file" accept="application/pdf" required>

        <button type="submit" name="upload">Upload PDF</button>
    </form>
</div>
</body>
</html>
