<?php
require('../dbconn.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['RollNo'])) {
    echo "<script>alert('Access Denied!'); window.location='../index.php';</script>";
    exit();
}

// Handle deletion
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Fetch filename
    $query = "SELECT filename FROM LMS.documents WHERE id = $id";
    $res = $conn->query($query);
    if ($res->num_rows > 0) {
        $file = $res->fetch_assoc()['filename'];
        $filePath = "../uploads/" . $file;

        // Delete file if exists
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Delete record
        $conn->query("DELETE FROM LMS.documents WHERE id = $id");

        echo "<script>alert('PDF deleted successfully'); window.location='managepdfs.php';</script>";
        exit();
    }
}

// Fetch all PDFs
$sql = "SELECT * FROM LMS.documents ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage PDFs</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f1f5f9;
            margin: 0;
            padding: 40px;
        }

        .container {
            max-width: 900px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #2c3e50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            padding: 14px 12px;
            border-bottom: 1px solid #e0e0e0;
            text-align: left;
        }

        th {
            background-color: #2c7be5;
            color: white;
            font-weight: 600;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        a {
            color: #2c7be5;
            text-decoration: none;
            font-weight: 500;
        }

        .delete-btn {
            color: red;
            margin-left: 10px;
        }

        a:hover {
            text-decoration: underline;
        }

        @media screen and (max-width: 600px) {
            body {
                padding: 20px;
            }
            .container {
                padding: 20px;
            }
            table, thead, tbody, th, td, tr {
                display: block;
            }
            th {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            tr {
                margin-bottom: 10px;
                border-bottom: 2px solid #ddd;
            }
            td {
                padding-left: 50%;
                position: relative;
                text-align: right;
            }
            td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                width: 45%;
                font-weight: bold;
                text-align: left;
                color: #555;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Uploaded PDFs</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Download</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $sn = 1; while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td data-label="#"><?= $sn++; ?></td>
                        <td data-label="Title"><?= htmlspecialchars($row['title']); ?></td>
                        <td data-label="Download">
                            <a href="../uploads/<?= urlencode($row['filename']); ?>" target="_blank">Download</a>
                        </td>
                        <td data-label="Action">
                            <a class="delete-btn" href="?delete=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this PDF?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No PDFs uploaded yet.</p>
    <?php endif; ?>
</div>
</body>
</html>
