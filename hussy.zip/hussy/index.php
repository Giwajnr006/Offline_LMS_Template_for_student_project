<?php
ob_start(); // Start output buffering to prevent header errors
session_start(); // Start session management
require('dbconn.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>Offline Library Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            color: #333;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 28px;
            color: #2c3e50;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            max-width: 1000px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .login, .register {
            flex: 1 1 400px;
            margin: 10px;
            padding: 20px;
        }

        input[type="text"], input[type="password"], input[type="email"], select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        input[type="submit"] {
            background: #3498db;
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        input[type="submit"]:hover {
            background: #2980b9;
        }

        h2 {
            color: #34495e;
            margin-bottom: 10px;
        }

        .send-button {
            margin-top: 10px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 14px;
            color: #888;
        }

        a.underline {
            text-decoration: underline;
            color: #3498db;
        }
    </style>
</head>
<body>

<!-- Header Bar -->
<div class="header-bar" style="display: flex; align-items: center; justify-content: center; background:rgb(241, 7, 7); padding: 10px 20px; color: white;">
    <img src="images/unilogo.png" alt="University Logo" style="height: 50px; margin-right: 15px;">
    <h1 style="margin: 0; font-family: 'Open Sans', sans-serif; font-size: 36px; font-weight: 700; color: white;">
        NEWGATE UNIVERSITY Offline Library Management System    
    </h1>
</div>

<div class="container">

    <!-- Login Form -->
    <div class="login" style="max-width: 400px; margin: 80px auto; padding: 30px; background: #ffffff; border: 1px solid #ddd; border-radius: 10px; box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
        <div style="text-align: center; margin-bottom: 15px;">
            <img src="images/profile.png" alt="User Icon"
                style="width: 90px; height: 90px; border-radius: 50%; border: 2px solid #0047AB; padding: 5px; object-fit: cover;">
        </div>
        <h2 style="text-align: center; color: #0047AB; margin-bottom: 25px;">Sign In</h2>
        <form action="index.php" method="post">
            <input type="text" name="RollNo" placeholder="Mat No." required
                style="width: 100%; padding: 12px 15px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 6px; font-size: 16px;">
            <input type="password" name="Password" placeholder="Password" required
                style="width: 100%; padding: 12px 15px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 6px; font-size: 16px;">
            <div class="send-button" style="text-align: center;">
                <input type="submit" name="signin" value="Sign In"
                    style="background: linear-gradient(to right, #0047AB, #FF0000); border: none; color: white; padding: 12px 25px; font-size: 16px; border-radius: 6px; cursor: pointer; transition: background 0.3s;">
            </div>
        </form>
    </div>

    <!-- Register Form -->
    <div class="register" style="max-width: 500px; margin: 60px auto; padding: 35px; background: #ffffff; border: 1px solid #ddd; border-radius: 12px; box-shadow: 0 0 20px rgba(0, 0, 0, 0.08); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
        <h2 style="text-align: center; color: #0047AB; margin-bottom: 25px;">Sign Up</h2>
        <form action="index.php" method="post">
            <input type="text" name="Name" placeholder="Name" required>
            <input type="text" name="Email" placeholder="Email" required>
            <input type="password" name="Password" placeholder="Password" required>
            <input type="text" name="PhoneNumber" placeholder="Phone Number" required>
            <input type="text" name="RollNo" placeholder="Mat No." required>
            <select name="Category" id="Category" required>
                <option value="GEN">General</option>
                <option value="OBC">Level 1</option>
                <option value="SC">Level 2</option>
                <option value="ST">Level 3</option>
            </select>
            <div class="send-button" style="text-align: center;">
                <input type="submit" name="signup" value="Sign Up"
                    style="background: linear-gradient(to right, #0047AB, #FF0000); border: none; color: white; padding: 12px 30px; font-size: 16px; border-radius: 6px; cursor: pointer; transition: background 0.3s;">
            </div>
        </form>
        <p style="text-align: center; margin-top: 20px; font-size: 14px;">
            By creating an account, you agree to our 
            <a class="underline" href="terms.html" style="color: #0047AB; text-decoration: underline;">Terms</a>
        </p>
    </div>

</div>

<div class="footer">
    <p>&copy; @gigzTek All Rights Reserved</p>
</div>

<?php
if (isset($_POST['signin'])) {
    $u = $_POST['RollNo'];
    $p = $_POST['Password'];
    $sql = "SELECT * FROM LMS.user WHERE RollNo='$u'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    if ($row && strcasecmp($row['Password'], $p) == 0 && !empty($u) && !empty($p)) {
        $_SESSION['RollNo'] = $u;
        if ($row['Type'] == 'Admin') {
            header('Location: admin/index.php');
            exit();
        } else {
            header('Location: student/index.php');
            exit();
        }
    } else {
        echo "<script type='text/javascript'>alert('Failed to Login! Incorrect RollNo or Password')</script>";
    }
}

if (isset($_POST['signup'])) {
    $name = $_POST['Name'];
    $email = $_POST['Email'];
    $password = $_POST['Password'];
    $mobno = $_POST['PhoneNumber'];
    $rollno = $_POST['RollNo'];
    $category = $_POST['Category'];
    $type = 'Student';

    $sql = "INSERT INTO LMS.user (Name, Type, Category, RollNo, EmailId, MobNo, Password)
            VALUES ('$name', '$type', '$category', '$rollno', '$email', '$mobno', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "<script type='text/javascript'>alert('Registration Successful')</script>";
    } else {
        echo "<script type='text/javascript'>alert('User Already Exists or Error')</script>";
    }
}
?>
</body>
</html>
