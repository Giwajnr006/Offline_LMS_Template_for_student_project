<?php
require('../dbconn.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['RollNo'])) {
    echo "<script>alert('Access Denied!'); window.location='../index.php';</script>";
    exit();
}

$results = null;
$allDocs = $conn->query("SELECT * FROM LMS.documents");

if (isset($_POST['search'])) {
    $query = $conn->real_escape_string($_POST['query']);
    $sql = "SELECT * FROM LMS.documents WHERE title LIKE '%$query%'";
    $results = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search PDFs</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Optional external style -->
    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            padding: 40px;
        }
        .pdf-search-container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #2c3e50;
        }
        form {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        input[type="text"] {
            width: 70%;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px 16px;
            background: #3498db;
            border: none;
            color: white;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background: #2980b9;
        }
        .search-results,
        .all-pdfs {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }
        th {
            background: #2c7be5;
            color: white;
        }
        tr:hover {
            background: #f1f1f1;
        }
        a {
            color: #2c7be5;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="pdf-search-container">
    <h2>Search PDF Documents</h2>

    <form method="post">
        <input type="text" name="query" placeholder="Enter PDF title..." required>
        <button type="submit" name="search">Search</button>
    </form>

    <div class="search-results">
        <?php
        if ($results) {
            echo "<h3>Search Results:</h3>";
            if ($results->num_rows > 0) {
                echo "<table>
                        <tr><th>Title</th><th>Download</th></tr>";
                while ($row = $results->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['title']}</td>
                            <td><a href='../uploads/{$row['filename']}' target='_blank'>Download</a></td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No PDFs found.</p>";
            }
        }
        ?>
    </div>

    <div class="all-pdfs">
        <h3>All Available PDFs:</h3>
        <table>
            <tr>
                <th>Title</th>
                <th>Download</th>
            </tr>
            <?php while ($doc = $allDocs->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($doc['title']) ?></td>
                    <td><a href="../uploads/<?= $doc['filename'] ?>" target="_blank">Download</a></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

</body>
</html>
